import sys
import re
import csv
import datetime
import com.cisco.wae.design

from argparse import ArgumentParser
from argparse import RawDescriptionHelpFormatter
from com.cisco.wae.design.model.net import DemandRecord
from com.cisco.wae.design.model.net import DemandEndpointKey
from com.cisco.wae.design.model.net import ServiceClassKey
from com.cisco.wae.design.model.net import TrafficLevelKey
from com.cisco.wae.design.model.traffic import DemandTrafficKey

def process_argv():
    '''
        Returns the cli arguments in a dictionary
    '''
    argv = list(sys.argv)
    options = {}
    argv.pop(0)
    while len(argv) > 0:
        item = argv.pop(0)
        next_item = argv.pop(0)
        options[re.sub(r'^-', '', item)] = next_item
    return options

def get_cli_options():
    '''
        Captures and validates the CLI options
    '''
    options = process_argv()
    return options

def update_demands(plan, demand_source, demand_dest, demand_traffic, demand_name, traffic_level_key):
    # Update demands table
    demand_manager = plan.getNetwork().getDemandManager()
    demand_traffic_manager = plan.getTrafficManager().getDemandTrafficManager()
    # Create new demand
    new_demand_record = DemandRecord(
        source=DemandEndpointKey(key=demand_source),
        destination=DemandEndpointKey(key=demand_dest),
        serviceClass=ServiceClassKey(name='Default'),
        name=demand_name,
    )
    new_demand = demand_manager.newDemand(new_demand_record)
    new_demand_key = new_demand.getKey()
    new_demand_traffic_key = DemandTrafficKey(dmdKey=new_demand_key, traffLvlKey=TrafficLevelKey(name=traffic_level_key))
    demand_traffic_manager.setTraffic(key=new_demand_traffic_key, traffic=float(demand_traffic))

def main(argv=None):
    
    options = get_cli_options()

    # Process arguments
    plan_file = options['plan-file']
    out_file = options['out-file']
    demands_file = options['demands-file']


    print(datetime.datetime.now())
    conn = com.cisco.wae.design.ServiceConnectionManager.newService()
    plan = conn.getPlanManager().newPlanFromFileSystem(plan_file)
    sim = conn.getSimulationManager()

    traffic_level_key = plan.getNetwork().getTrafficLevelManager().getAllTrafficLevelKeys()[0].name

    # Collect data from input files
    demands_file_dict = csv.DictReader(open(demands_file, 'r'))
    # Create demands data dictionaries with inputs from files
    for demand in demands_file_dict:
        print(demand)
        demand_source = demand["source"]
        demand_dest = demand['destination']
        demand_traffic = demand['traffic']
        demand_name = demand['name']
        update_demands(plan, demand_source, demand_dest, demand_traffic, demand_name, traffic_level_key)

    plan.serializeToFileSystem(out_file)
    com.cisco.wae.design.ServiceConnectionManager.shutdownService(conn)
    print(datetime.datetime.now())

# end main()


if __name__ == '__main__':
    main()
    exit(0)