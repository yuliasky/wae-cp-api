import sys
import re
import csv
import pprint
import tomllib
import datetime
import com.cisco.wae.design

from com.cisco.wae.design.model.net import DemandRecord
from com.cisco.wae.design.model.net import PortRecord
from com.cisco.wae.design.model.net import ServiceClassRecord
from com.cisco.wae.design.model.net import LSPRecord
from com.cisco.wae.design.model.net import SRLGRecord
from com.cisco.wae.design.model.net import DemandEndpointKey
from com.cisco.wae.design.model.net import ServiceClassKey
from com.cisco.wae.design.model.net import TrafficLevelKey
from com.cisco.wae.design.model.traffic import DemandTrafficKey
from com.cisco.wae.design.model.net import NodeKey
from com.cisco.wae.design.model.net import PortKey
from com.cisco.wae.design.model.net import InterfaceKey
from com.cisco.wae.design.model.net import CircuitKey
from com.cisco.wae.design.model.net import AdminGroupKey

def process_argv():
    '''
        Returns the cli arguments in a dictionary
    '''
    argv = list(sys.argv)
    options = {}
    argv.pop(0)
    while len(argv) > 0:
        item = argv.pop(0)
        next_item = argv.pop(0)
        options[re.sub(r'^-', '', item)] = next_item
    return options

def get_cli_options():
    '''
        Captures and validates the CLI options
    '''
    options = process_argv()
    return options

def update_demand_list(plan, demandList, traffic_level_key):
    demand_manager = plan.getNetwork().getDemandManager()
    demand_traffic_manager = plan.getTrafficManager().getDemandTrafficManager()
    demandRecList = []
    demandTrafficDic = {}
    for demand in demandList:
        if demand['type'] == 'prod':
            demand_source = demand['src']
            demand_dest = demand['dst']
            demand_traffic = demand['demand_mbps']
            demand_name = demand['name']
            demandRec = DemandRecord(
                source=DemandEndpointKey(key=demand_source),
                destination=DemandEndpointKey(key=demand_dest),
                serviceClass=ServiceClassKey(name='Default'),
                name=demand_name,)
            demandRecList.append(demandRec)
            '''
                Assuming each newly created demand has an unique name
            '''
            demandTrafficDic[demand_name] = demand_traffic
    new_demands = demand_manager.newDemands(recs=demandRecList)
    print("Setting traffic")
    print(datetime.datetime.now())
    print(new_demands)
    print(demandTrafficDic)
    demandTrafficMap = {}
    for key, dmd in new_demands.items():
        new_demand_traffic_key = DemandTrafficKey(dmdKey=key, traffLvlKey=TrafficLevelKey(name=traffic_level_key))
        demandTrafficMap[new_demand_traffic_key] = float(demandTrafficDic[dmd.getName()])
    demand_traffic_manager.setTraffics(demandTrafficMap)

def insert_ports(plan, ports):
    interface_manager = plan.getNetwork().getInterfaceManager()
    circuit_manager = plan.getNetwork().getCircuitManager()
    port_manager = plan.getNetwork().getPortManager()

    portKeyList = []

    for port in ports:
        if port['capacity_percent'] == 75:
            srlg_indexes = [4]
        elif port['capacity_percent'] == 50:
            srlg_indexes = [3, 4]
        elif port['capacity_percent'] == 25:
            srlg_indexes = [2, 3, 4]
        else:
            srlg_indexes = [1, 2, 3, 4]

        node_a = port['link'].split('/')[0]
        source_node_a = NodeKey(name=node_a)
        print(source_node_a)
        print(node_a)
        node_b = port['link'].split('/')[1]
        source_node_b = NodeKey(name=node_b)
        print(source_node_b)
        print(node_b)
        index = 4
        div_capacity = 4
        while index > 0:
            port_name_a = port['link'] + f'-{index}'
            print(port_name_a)
            port_name_b = f'{node_b}/{node_a}-{index}'
            if not port_manager.hasPort(key=PortKey(sourceKey=source_node_a, name=port_name_a)):
                iface_a = interface_manager.getInterface(key=InterfaceKey(sourceKey=source_node_a, name=f'{node_a}/{node_b}'))
                iface_b = interface_manager.getInterface(key=InterfaceKey(sourceKey=source_node_b, name=f'{node_b}/{node_a}'))
                circuit_key = CircuitKey(interfaceAKey=iface_a.getKey(), interfaceBKey=iface_b.getKey())
                circuit = circuit_manager.getCircuit(key=circuit_key)

                port_rec_a = PortRecord(
                   sourceKey=source_node_a,
                   name=port_name_a,
                   ifaceKey=iface_a.getKey(),
                   capacity=circuit.getCapacity()/div_capacity
                )
                port_manager.newPort(portRec=port_rec_a)
                print(f'Port inserted: {port_name_a}')

                port_rec_b = PortRecord(
                   sourceKey=source_node_b,
                   name=port_name_b,
                   ifaceKey=iface_b.getKey(),
                   capacity=circuit.getCapacity()/div_capacity
                )
                port_manager.newPort(portRec=port_rec_b)
                print(f'Port inserted: {port_name_b}')

                if index == 1:
                    circuit.unsetCapacity()
                    #iface_a.unsetCapacity()
                    #iface_b.unsetCapacity()

            if index in srlg_indexes:
                print(f"Index is: {index}")
                print(srlg_indexes)
                portKeyList.append(PortKey(sourceKey=source_node_a, name=port_name_a))
                portKeyList.append(PortKey(sourceKey=source_node_b, name=port_name_b))

            index = index - 1

    return portKeyList

def update_srlgs(plan, srlgRecList):
    srlg_manager = plan.getNetwork().getSRLGManager()

    srlg_map = srlg_manager.newSRLGs(recs=srlgRecList)
    print(f'SRLGs inserted: {srlg_map}')

def update_lsps(plan, lspRecList):
    lsp_manager = plan.getNetwork().getLSPManager()

    lsp_map = lsp_manager.newLSPs(recs=lspRecList)
    print(f'LSPs inserted: {lsp_map}')

def main(argv=None):

    options = get_cli_options()

    # Process arguments
    plan_file = options['plan-file']
    out_file = options['out-file']
    insert_demands = options['insert-demands']
    insert_srlgs = options['insert-srlgs']
    insert_lsps = options['insert-lsps']

    print(datetime.datetime.now())
    conn = com.cisco.wae.design.ServiceConnectionManager.newService()
    plan = conn.getPlanManager().newPlanFromFileSystem(plan_file)

    traffic_level_key = plan.getNetwork().getTrafficLevelManager().getAllTrafficLevelKeys()[0].name

    if insert_demands == 'true':
        print("Inserting demands")
        demands_file = options['demands-file']
        # Collect data from input files
        demands_file_dict = csv.DictReader(open(demands_file, 'r'))
        demand_dict_list=list(demands_file_dict)
        update_demand_list(plan, demand_dict_list, traffic_level_key)

    if insert_srlgs == 'true':
        print("Inserting ports")
        srlgs_file = options['srlgs-file']
        # Collect data from input files
        try:
            srlgs_file_list = tomllib.load(open(srlgs_file, 'rb'))['cases']
            pprint.pprint(srlgs_file_list)
        except tomllib.TOMLDecodeError as e:
            print(f"Error decoding TOML: {e}")

        srlgRecList = []
        for srlg in srlgs_file_list:
            ports = srlg['impact']
            portKeyList = insert_ports(plan, ports)
            srlgRec = SRLGRecord(
                name=srlg['name'],
                portKeys=portKeyList
            )
            srlgRecList.append(srlgRec)

        print("Inserting srlgs")
        update_srlgs(plan, srlgRecList)

    if insert_lsps == 'true':
        print("Inserting LSPs")
        lsps_file = options['lsps-file']
        # Collect data from input files
        try:
            lsps_file_list = tomllib.load(open(lsps_file, 'rb'))['rules']
            pprint.pprint(lsps_file_list)
        except tomllib.TOMLDecodeError as e:
            print(f"Error decoding TOML: {e}")

        admin_group_manager = plan.getNetwork().getAdminGroupManager()
        admin_group_map = admin_group_manager.getAllAdminGroups()

        lspRecList = []
        for lsp in lsps_file_list:
            affinity_list = []
            for color in lsp['exclude_colors']:
                admin_group_key = AdminGroupKey(name=color)
                if admin_group_key in admin_group_map:
                    affinity_list.append(admin_group_map[admin_group_key].affinity)
                else:
                    pass

            lspRec = LSPRecord(
                sourceKey=NodeKey(name=lsp['src']),
                destinationKey=NodeKey(name=lsp['dst']),
                name=lsp['name'],
                excludeAffinities=affinity_list
            )
            lspRecList.append(lspRec)

        update_lsps(plan, lspRecList)

    plan.serializeToFileSystem(out_file)
    com.cisco.wae.design.ServiceConnectionManager.shutdownService(conn)
    print(datetime.datetime.now())
# end main()


if __name__ == '__main__':
    main()
    exit(0)
