import os
import sys
import re
import csv
import datetime
import tomllib
import pprint
import com.cisco.wae.design

from argparse import ArgumentParser
from argparse import RawDescriptionHelpFormatter
from com.cisco.wae.design.model.net import NodeKey
from com.cisco.wae.design.model.net import InterfaceKey
from com.cisco.wae.design.model.net import NodeRecord
from com.cisco.wae.design.model.net import InterfaceRecord
from com.cisco.wae.design.model.net import CircuitRecord
from com.cisco.wae.design.model.net import AdminGroupRecord
from com.cisco.wae.design.model.net import OspfArea
from com.cisco.wae.design.model.net import TrafficLevelKey
from com.cisco.wae.design.model.net import AdminGroupKey
from com.cisco.wae.design.model.net import QueueKey
from com.cisco.wae.design.model.net import ServiceClassKey
from com.cisco.wae.design.model.net import ServiceClassRecord

def process_argv():
    '''
        Returns the cli arguments in a dictionary
    '''
    argv = list(sys.argv)
    options = {}
    argv.pop(0)
    while len(argv) > 0:
        item = argv.pop(0)
        next_item = argv.pop(0)
        options[re.sub(r'^-', '', item)] = next_item
    return options

def get_cli_options():
    '''
        Captures and validates the CLI options
    '''
    options = process_argv()
    return options

def insert_node(plan, node_name):
    network = plan.getNetwork()
    node_manager = plan.getNetwork().getNodeManager()

    node_rec = NodeRecord(
        name=node_name
    )

    new_node = node_manager.newNode(nodeRec=node_rec)

    print("New node has been created: {}".format(new_node.getName()))

def insert_circuits(plan, node_a_name, int_a_name, node_b_name, int_b_name, circuit_capacity):
    network = plan.getNetwork()
    circuit_manager = plan.getNetwork().getCircuitManager()
    interface_manager = plan.getNetwork().getInterfaceManager()

    int_a_key = InterfaceKey(sourceKey=NodeKey(name=node_a_name), name=int_a_name)

    if not interface_manager.hasInterface(key=int_a_key):
        int_a_rec = InterfaceRecord(
            sourceKey=NodeKey(name=node_a_name),
            name=int_a_name
        )
        int_b_rec = InterfaceRecord(
            sourceKey=NodeKey(name=node_b_name),
            name=int_b_name
        )
        int_b_key = InterfaceKey(sourceKey=NodeKey(name=node_b_name), name=int_b_name)
        circuit_rec = CircuitRecord(
            interfaceAKey=int_a_key,
            interfaceBKey=int_b_key,
        )
        new_circuit = network.newConnection(ifaceARec=int_a_rec, ifaceBRec=int_b_rec, circuitRec=circuit_rec)
        has_circuit = circuit_manager.hasCircuit(key=new_circuit.getKey())
        print("New circuit has been created: {}".format(has_circuit))
        if has_circuit:
            if circuit_capacity != 'na':
                new_circuit.setCapacity(float(circuit_capacity)*1000)

def insert_admin_group(plan, int_admin_group):
    network = plan.getNetwork()
    admin_group_manager = plan.getNetwork().getAdminGroupManager()

    admin_group_map = admin_group_manager.getAllAdminGroups()
    print(admin_group_map)

    admin_group_name_list = []
    if not admin_group_map:
        affinity_id = 31
    else:
        admin_group_aff_list = []
        for admin_group in admin_group_map:
            admin_group_aff_list.append(admin_group_map[admin_group].affinity)
            admin_group_name_list.append(admin_group_map[admin_group].name)
        admin_group_aff_list.sort(reverse=True)
        affinity_id = admin_group_aff_list[0]

    int_aff_list = []
    for color in int_admin_group:
        affinity_id = affinity_id + 1
        admin_group_rec = AdminGroupRecord(
            name=color,
            affinity=affinity_id
        )
        if not admin_group_name_list:
            admin_group_manager.newAdminGroup(rec=admin_group_rec)
            int_aff_list.append(affinity_id)
            print("This is the admin group added: {}".format(color))
        else:
            if color not in admin_group_name_list:
                admin_group_manager.newAdminGroup(rec=admin_group_rec)
                int_aff_list.append(affinity_id)
                print("This is the admin group added: {}".format(color))
            else:
                affinity_id = affinity_id - 1
                existing_admin_group_rec = admin_group_manager.getAdminGroup(key=AdminGroupKey(name=color))
                existing_affinity_id = existing_admin_group_rec.affinity
                int_aff_list.append(existing_affinity_id)
                print("This admin group already exists: {}".format(color))

    return int_aff_list

def update_interfaces(plan, node_a_name, int_a_name, int_igp_metric, int_ospf_area, int_isis_level, int_igp_proc_id, int_traffic, int_aff_list, default_level, default_queue):
    interface_manager = plan.getNetwork().getInterfaceManager()

    int_a_key = InterfaceKey(sourceKey=NodeKey(name=node_a_name), name=int_a_name)
    if interface_manager.hasInterface(key=int_a_key):
        int_a = interface_manager.getInterface(key=int_a_key)
        int_a.setIGPMetric(val=int(int_igp_metric))
        int_a.setISISLevel(val=int(int_isis_level))
        int_a.setIGPProcessID(val=int_igp_proc_id)
        if int_ospf_area != 'na':
            int_a.setOSPFArea(oa=OspfArea(ipAddress=int_ospf_area, isBackbone=True))

        if int_traffic != 'na':
            int_meas_traffic = plan.getTrafficManager().getMeasuredTrafficManager().getInterfaceMeasuredTraffic()
            int_meas_traffic.setInterfaceTrafficValue(ifc=int_a, trafficLevel=default_level, queue=default_queue, traffic=float(int_traffic))

        if int_aff_list != 'na':
            int_a.setAffinities(val=int_aff_list)


def main(argv=None):
    
    options = get_cli_options()

    # Process arguments
    plan_file = options['plan-file']
    out_file = options['out-file']
    interfaces_file = options['interfaces-file']


    print(datetime.datetime.now())
    conn = com.cisco.wae.design.ServiceConnectionManager.newService()
    plan = conn.getPlanManager().newPlanFromFileSystem(plan_file)

    traffic_level_key = plan.getNetwork().getTrafficLevelManager().getAllTrafficLevelKeys()[0].name
    default_level = plan.getNetwork().getTrafficLevelManager().getTrafficLevel(TrafficLevelKey(name=traffic_level_key))
    default_queue = plan.getNetwork().getQueueManager().getQueue(QueueKey(name=traffic_level_key))
    service_class_manager = plan.getNetwork().getServiceClassManager()
    if not service_class_manager.hasServiceClass(key=ServiceClassKey(name='Default')):
        service_class_manager.newServiceClass(serviceClassRec=ServiceClassRecord(name='Default'))

    # Collect data from input files
    _, extension = os.path.splitext(interfaces_file)
    if extension.lower() == ".csv":
        interfaces_file_dict = csv.DictReader(open(interfaces_file, 'r'))
    else:
        try:
            interfaces_file_dict = tomllib.load(open(interfaces_file, 'rb'))['links']
            pprint.pprint(interfaces_file_dict)
        except tomllib.TOMLDecodeError as e:
            print(f"Error decoding TOML: {e}")
    
    # Create circuits data dictionaries with inputs from file
    for interface in interfaces_file_dict:
        print(interface)
        node_manager = plan.getNetwork().getNodeManager()
        node_a_name = interface['src']
        node_b_name = interface['dst']
        if not node_manager.hasNode(key=NodeKey(name=node_a_name)):
            insert_node(plan, node_a_name)
        if not node_manager.hasNode(key=NodeKey(name=node_b_name)):
            insert_node(plan, node_b_name)
        int_a_name = interface['forward_name']
        int_b_name = interface['reverse_name']
        circuit_capacity = interface['capacity_gbps']
        insert_circuits(plan, node_a_name, int_a_name, node_b_name, int_b_name, circuit_capacity)
        int_igp_metric = interface.get('metric', '10')
        int_ospf_area = interface.get('ospf_area', '0.0.0.0')
        int_isis_level = interface.get('isis_Level', '2')
        int_traffic = interface.get('traff_meas', 'na')
        int_igp_proc_id = interface.get('igp_proc_id')
        int_admin_group = interface.get('colors','na')
        if int_admin_group != 'na':
            int_aff_list = insert_admin_group(plan, int_admin_group)
        else:
            int_aff_list = 'na'
        update_interfaces(plan, node_a_name, int_a_name, int_igp_metric, int_ospf_area, int_isis_level, int_igp_proc_id, int_traffic, int_aff_list, default_level, default_queue)
        if extension.lower() == ".toml":
            update_interfaces(plan, node_b_name, int_b_name, int_igp_metric, int_ospf_area, int_isis_level, int_igp_proc_id, int_traffic, int_aff_list, default_level, default_queue)


    plan.serializeToFileSystem(out_file)
    com.cisco.wae.design.ServiceConnectionManager.shutdownService(conn)
    print(datetime.datetime.now())

# end main()


if __name__ == '__main__':
    main()
    exit(0)